def fetch_flows():
    # Placeholder for Salesforce CLI logic
    return [("Sample_Flow", {"label": "Sample Flow"})]
