import os
import logging
import config
import sf_loader
import sf_object_loader
from confluence_client import ConfluenceClient
from confluence_uploader import ConfluenceUploader

# Ensure logs folder exists
os.makedirs(config.LOG_DIR, exist_ok=True)
logfile = os.path.join(config.LOG_DIR, f"uploadflows_{config.RUN_TS_SAFE}.log")

logging.basicConfig(
    level=logging.DEBUG if config.DEBUG else logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[logging.FileHandler(logfile), logging.StreamHandler()],
)
logger = logging.getLogger(__name__)
logger.info("Logging to %s", logfile)


def process_flows(uploader, parent_id):
    """Upload all flows to Confluence in Fabric JSON format."""
    rows = sf_loader.fetch_all()
    for row in rows:
        flow_name = row.get("flowName")
        logger.info(f"Uploading flow: {flow_name}")
        uploader.upload_flow_doc(
            parent_id=parent_id,
            name=flow_name,
            meta=row
        )


def process_objects(uploader, parent_id):
    """Upload all objects to Confluence in Fabric JSON format."""
    objects = sf_object_loader.fetch_all_objects(config.SF_CLI, config.SF_ORG_ALIAS)
    for obj in objects:
        object_name = obj["name"]
        fields = obj.get("fields", [])
        logger.info(f"Uploading object: {object_name}")
        uploader.upload_object_doc(
            parent_id=parent_id,
            object_name=object_name,
            fields=fields,
            meta=obj
        )


def run():
    logger.info("Using Confluence Base URL: %s", config.CONFLUENCE_BASE_URL)

    # Initialize Confluence client + uploader
    client = ConfluenceClient(
        base_url=config.CONFLUENCE_BASE_URL,
        email=config.CONFLUENCE_EMAIL,
        api_token=config.CONFLUENCE_API_TOKEN,
        space_id=config.CONFLUENCE_SPACE_ID
    )
    uploader = ConfluenceUploader(client)

    # Upload flows
    process_flows(uploader, config.FLOW_FOLDER)

    # Upload objects
    process_objects(uploader, config.OBJECT_FOLDER)


if __name__ == "__main__":
    run()
