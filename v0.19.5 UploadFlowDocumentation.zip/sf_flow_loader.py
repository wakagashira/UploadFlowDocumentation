import os
import subprocess
import xml.etree.ElementTree as ET
import logging
import tempfile
import shutil
import json
import shlex
from dotenv import load_dotenv

# Load .env so SF_CLI, SF_ORG_ALIAS, etc. are available
load_dotenv()

logger = logging.getLogger(__name__)

def run_cli(cmd):
    """Run an sf/sfdx CLI command and return stdout or raise error."""
    logger.debug("Running CLI: %s", " ".join(cmd))
    result = subprocess.run(cmd, capture_output=True, text=True, shell=False)
    if result.returncode != 0:
        raise RuntimeError(f"CLI failed: {result.stderr.strip()}")
    return result.stdout

def try_cmd_variants(base_cmd, org_alias, username=None):
    """
    Try multiple flag styles until one works:
    --target-org, -o, -u
    If org_alias fails, try username as fallback.
    """
    variants = []
    if org_alias:
        variants.extend([
            base_cmd + ["--target-org", org_alias],
            base_cmd + ["-o", org_alias],
            base_cmd + ["-u", org_alias],
        ])
    if username:
        variants.extend([
            base_cmd + ["--target-org", username],
            base_cmd + ["-o", username],
            base_cmd + ["-u", username],
        ])

    last_err = None
    for cmd in variants:
        try:
            logger.info("🔎 Trying CLI variant: %s", " ".join(cmd))
            out = run_cli(cmd)
            logger.info("✅ Success with variant: %s", " ".join(cmd))
            return out
        except Exception as e:
            logger.warning("❌ Variant failed: %s", e)
            last_err = e
    raise last_err

def fetch_all():
    # Read CLI path from .env
    sf_cli = os.getenv("SF_CLI", "sf")
    org_alias = os.getenv("SF_ORG_ALIAS", "Prod")
    username = os.getenv("SF_USERNAME", "Ambrose@creteunited.com")

    # Quote path if it has spaces
    if " " in sf_cli and not sf_cli.startswith('"'):
        sf_cli = f'"{sf_cli}"'

    # Split into list safely
    sf_cli_parts = shlex.split(sf_cli)

    # Step 1: list active flow definitions
    query = """
    SELECT Id, DeveloperName, MasterLabel, ActiveVersionId
    FROM FlowDefinition
    WHERE ActiveVersionId != null
    """
    base_cmd = sf_cli_parts + ["data", "query", "-q", query, "--json"]

    # Try Prod alias first, then username fallback
    output = try_cmd_variants(base_cmd, org_alias, username)

    data = json.loads(output)
    if "result" not in data or "records" not in data["result"]:
        logger.error("No FlowDefinitions found")
        return []

    defs = data["result"]["records"]
    all_rows = []

    # Step 2: loop through flows
    for rec in defs:
        dev_name = rec.get("DeveloperName")
        master_label = rec.get("MasterLabel")
        flow_id = rec.get("Id")

        logger.info("Fetching metadata for flow: %s (%s)", master_label, dev_name)

        # Make a temp dir to hold the retrieved metadata
        temp_dir = tempfile.mkdtemp()
        try:
            # Retrieve the flow’s metadata XML via CLI
            base_retrieve = sf_cli_parts + [
                "project", "retrieve", "start",
                "-m", f"Flow:{dev_name}", "--json"
            ]
            try:
                try_cmd_variants(base_retrieve, org_alias, username)
            except Exception as e:
                logger.warning("Failed to retrieve flow %s: %s", dev_name, e)
                continue

            # Look for the XML file in force-app/main/default/flows
            flows_path = os.path.join("force-app", "main", "default", "flows")
            xml_file = os.path.join(flows_path, f"{dev_name}.flow-meta.xml")

            fields = []
            if os.path.exists(xml_file):
                try:
                    tree = ET.parse(xml_file)
                    root = tree.getroot()
                    tags_to_check = [
                        ".//field",
                        ".//targetField",
                        ".//inputParameters//field",
                        ".//outputParameters//field",
                        ".//object",
                    ]
                    for path in tags_to_check:
                        for elem in root.findall(path):
                            if elem.text and elem.text not in fields:
                                fields.append(elem.text)
                except Exception as e:
                    logger.warning("Could not parse XML for %s: %s", dev_name, e)
            else:
                logger.warning("XML file not found for %s", dev_name)

            meta = {
                "id": flow_id,
                "apiName": dev_name,
                "masterLabel": master_label,
            }
            all_rows.append((master_label, fields, meta))

        finally:
            # Cleanup retrieved files if desired
            if os.path.exists("force-app"):
                shutil.rmtree("force-app", ignore_errors=True)

    return all_rows
